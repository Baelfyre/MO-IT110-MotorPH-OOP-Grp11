/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.motorph.service.strategy;

/**
 *
 * @author ACER
 */
public interface DeductionStrategy {

    // [Method Dictionary Implementation]
    double calculateSSS(double grossPay);

    double calculatePhilHealth(double grossPay);

    double calculatePagibig(double grossPay);

    double calculateTax(double taxableIncome);
}
