/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.motorph.repository.csv;

import com.motorph.domain.enums.Role;
import com.motorph.domain.models.User;
import com.motorph.repository.UserRepository;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Legacy login CSV repository.
 *
 * Expected CSV format (6 columns):
 * Username,Password,Employee_ID,Employee_Name,Department,Lock_Out_Status
 */
public class CsvUserRepository implements UserRepository {

    private static final String FILE_PATH = DataPaths.LOGIN_CSV;

    @Override
    public User findByUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            return null;
        }

        String target = username.trim();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean headerChecked = false;

            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                String[] data = line.split(",", -1);

                // Skip header if present
                if (!headerChecked) {
                    headerChecked = true;
                    if (data.length > 0 && "Username".equalsIgnoreCase(data[0].trim())) {
                        continue;
                    }
                }

                // Legacy requires 6 columns
                if (data.length < 6) {
                    continue;
                }

                String fileUsername = data[0].trim();
                if (!fileUsername.equalsIgnoreCase(target)) {
                    continue;
                }

                String passwordPlain = data[1].trim();
                String department = data[4].trim();
                String lockStr = data[5].trim();

                boolean isLocked = lockStr.equalsIgnoreCase("Yes")
                        || lockStr.equalsIgnoreCase("Y")
                        || lockStr.equalsIgnoreCase("True");

                Role role = determineRoleFromDepartment(department);

                int id = safeParseInt(data[2].trim(), safeParseInt(fileUsername, 0));

                return new User(id, fileUsername, passwordPlain, role, isLocked);
            }

        } catch (IOException e) {
            System.err.println("Error reading legacy login file: " + e.getMessage());
        }

        return null;
    }

    @Override
    public void save(User account, String firstName, String lastName, String dept) {
        if (account == null) {
            return;
        }

        String username = safeCsv(account.getUsername());
        String password = safeCsv(account.getPassword());
        String lockOut = account.isLocked() ? "Yes" : "No";

        String employeeId = String.valueOf(account.getId() > 0 ? account.getId() : safeParseInt(username, 0));
        String employeeName = buildEmployeeName(firstName, lastName);

        // Username,Password,Employee_ID,Employee_Name,Department,Lock_Out_Status
        String row = String.join(",",
                username,
                password,
                safeCsv(employeeId),
                safeCsv(employeeName),
                safeCsv(dept),
                lockOut
        );

        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(FILE_PATH, true)))) {
            out.println(row);
        } catch (IOException e) {
            System.err.println("Error saving legacy user: " + e.getMessage());
        }
    }

    @Override
    public void updatePassword(String username, String newPassword) {
        if (username == null || username.trim().isEmpty()) {
            return;
        }

        List<String> lines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean headerHandled = false;

            while ((line = br.readLine()) != null) {
                if (!headerHandled) {
                    headerHandled = true;
                    lines.add(line); // keep header
                    continue;
                }

                if (line.trim().isEmpty()) {
                    lines.add(line);
                    continue;
                }

                String[] data = line.split(",", -1);
                if (data.length < 6) {
                    lines.add(line);
                    continue;
                }

                if (data[0].trim().equalsIgnoreCase(username.trim())) {
                    data[1] = newPassword == null ? "" : newPassword.trim();
                    line = String.join(",", data);
                }

                lines.add(line);
            }

        } catch (IOException e) {
            System.err.println("Error reading legacy login file for password update: " + e.getMessage());
            return;
        }

        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (String l : lines) {
                out.println(l);
            }
        } catch (IOException e) {
            System.err.println("Error rewriting legacy login file for password update: " + e.getMessage());
        }
    }

    @Override
    public void updateLockStatus(String username, boolean isLocked) {
        if (username == null || username.trim().isEmpty()) {
            return;
        }

        List<String> lines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            boolean headerHandled = false;

            while ((line = br.readLine()) != null) {
                if (!headerHandled) {
                    headerHandled = true;
                    lines.add(line); // keep header
                    continue;
                }

                if (line.trim().isEmpty()) {
                    lines.add(line);
                    continue;
                }

                String[] data = line.split(",", -1);
                if (data.length < 6) {
                    lines.add(line);
                    continue;
                }

                if (data[0].trim().equalsIgnoreCase(username.trim())) {
                    data[5] = isLocked ? "Yes" : "No";
                    line = String.join(",", data);
                }

                lines.add(line);
            }

        } catch (IOException e) {
            System.err.println("Error reading legacy login file for lock update: " + e.getMessage());
            return;
        }

        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (String l : lines) {
                out.println(l);
            }
        } catch (IOException e) {
            System.err.println("Error rewriting legacy login file for lock update: " + e.getMessage());
        }
    }

    private Role determineRoleFromDepartment(String department) {
        if (department == null) {
            return Role.EMPLOYEE;
        }

        String d = department.trim().toUpperCase();

        if (d.contains("HR")) {
            return Role.HR;
        }
        if (d.contains("PAYROLL") || d.contains("FINANCE") || d.contains("ACCOUNTING")) {
            return Role.PAYROLL;
        }
        if (d.contains("MANAGER") || d.contains("MANAGEMENT")) {
            return Role.MANAGER;
        }
        if (d.equals("IT OPERATIONS AND SYSTEMS") || d.contains("IT ")) {
            return Role.IT;
        }

        return Role.EMPLOYEE;
    }

    private int safeParseInt(String value, int fallback) {
        try {
            return Integer.parseInt(value.trim());
        } catch (Exception e) {
            return fallback;
        }
    }

    private String safeCsv(String value) {
        // Avoid commas because CSV parsing is split-based.
        return value == null ? "" : value.trim();
    }

    private String buildEmployeeName(String firstName, String lastName) {
        String fn = safeCsv(firstName);
        String ln = safeCsv(lastName);

        if (fn.isEmpty() && ln.isEmpty()) {
            return "";
        }
        if (ln.isEmpty()) {
            return fn;
        }
        if (fn.isEmpty()) {
            return ln;
        }

        // Format: Last, First
        return ln + ", " + fn;
    }

    @Override
    public boolean deleteByUsername(String username) {
        if (username == null) {
            return false;
        }

        java.nio.file.Path path = java.nio.file.Paths.get(DataPaths.LOGIN_CSV);

        if (!java.nio.file.Files.exists(path)) {
            return false;
        }

        try {
            java.util.List<String> lines = java.nio.file.Files.readAllLines(path);
            if (lines.isEmpty()) {
                return false;
            }

            String header = lines.get(0);
            java.util.List<String> out = new java.util.ArrayList<>();
            out.add(header);

            boolean removed = false;

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line == null || line.trim().isEmpty()) {
                    continue;
                }

                String[] parts = line.split(",", -1);
                if (parts.length == 0) {
                    continue;
                }

                String rowUsername = unquote(parts[0]).trim();
                if (rowUsername.equals(username.trim())) {
                    removed = true;
                    continue;
                }

                out.add(line);
            }

            if (!removed) {
                return false;
            }

            java.nio.file.Files.write(
                    path,
                    out,
                    java.nio.charset.StandardCharsets.UTF_8,
                    java.nio.file.StandardOpenOption.TRUNCATE_EXISTING,
                    java.nio.file.StandardOpenOption.CREATE
            );

            return true;

        } catch (Exception e) {
            return false;
        }
    }

    private String unquote(String s) {
        if (s == null) {
            return "";
        }
        String v = s.trim();
        if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) {
            v = v.substring(1, v.length() - 1);
            v = v.replace("\"\"", "\"");
        }
        return v;
    }
}
