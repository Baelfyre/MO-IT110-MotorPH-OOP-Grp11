/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.motorph.ui.swing;

import com.motorph.domain.models.User;
import com.motorph.ops.auth.AuthOps;
import com.motorph.service.EmployeeService;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JOptionPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.DocumentFilter;
import javax.swing.text.DocumentFilter.FilterBypass;
import com.motorph.ops.time.TimeOps;
import com.motorph.ops.hr.HROps;
import com.motorph.ops.payroll.PayrollOps;
import com.motorph.ops.payslip.PayslipOps;
import com.motorph.ops.supervisor.SupervisorOps;
import com.motorph.ops.leave.LeaveOps;
import com.motorph.ops.it.ItOps;
import com.motorph.repository.csv.CsvAddressReferenceRepository;
import com.motorph.service.LeaveCreditsService;

/**
 *
 * @author ACER
 */
public class LoginPanel extends javax.swing.JFrame {

    // Placeholder text kept as constants to align input validation and filters.
    private static final String USER_PLACEHOLDER = "EMPLOYEE ID";
    private static final String PASS_PLACEHOLDER = "PASSWORD";

    // Dependencies injected via constructor
    private final AuthOps authOps;
    private final EmployeeService employeeService;
    private final TimeOps timeOps;
    private final HROps hrOps;
    private final PayrollOps payrollOps;
    private final PayslipOps payslipOps;
    private final SupervisorOps supervisorOps;
    private final LeaveOps leaveOps;
    private final ItOps itOps;
    private final LeaveCreditsService leaveCreditsService;
    private final CsvAddressReferenceRepository addressRepo;

    public LoginPanel(AuthOps authOps, EmployeeService employeeService, TimeOps timeOps, HROps hrOps,
            PayrollOps payrollOps, PayslipOps payslipOps, SupervisorOps supervisorOps, LeaveOps leaveOps, ItOps itOps,
            LeaveCreditsService leaveCreditsService, CsvAddressReferenceRepository addressRepo) {
        this.authOps = authOps;
        this.employeeService = employeeService;
        this.timeOps = timeOps;
        this.hrOps = hrOps;
        this.payrollOps = payrollOps;
        this.payslipOps = payslipOps;
        this.supervisorOps = supervisorOps;
        this.leaveOps = leaveOps;
        this.itOps = itOps;
        this.leaveCreditsService = leaveCreditsService;
        this.addressRepo = addressRepo;

        initComponents();
        setSize(400, 600);
        setResizable(false);
        setExtendedState(javax.swing.JFrame.NORMAL);
        setLocationRelativeTo(null);

        setupNumberOnlyFilter();
        setupGhostText();

        this.requestFocusInWindow();
    }
    // --- LOGIC: PERFORM LOGIN ---
    private void performLogin() {
        String username = jTextField1.getText().trim();
        String password = new String(jPasswordField1.getPassword());

        if (username.equals(USER_PLACEHOLDER) || password.equals(PASS_PLACEHOLDER) || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Employee ID and password.", "Missing Info", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Delegate to the Ops layer
        User loggedInUser = authOps.login(username, password);

        if (loggedInUser != null) {
            // Success: Pass the user AND the pre-configured service to the dashboard
            new MainDashboard(loggedInUser, employeeService, authOps, timeOps, hrOps, payrollOps, payslipOps, supervisorOps, leaveOps, itOps, leaveCreditsService, addressRepo).setVisible(true);
            this.dispose();
        } else {
            // Failure: Show Error
            JOptionPane.showMessageDialog(this, "Invalid credentials.", "Login Error", JOptionPane.ERROR_MESSAGE);
            jPasswordField1.setText("");
            jPasswordField1.setForeground(Color.GRAY);
            jPasswordField1.setEchoChar((char) 0);
            jPasswordField1.setText(PASS_PLACEHOLDER);
        }
    }

    // --- UI FEATURE: GHOST TEXT ---
    private void setupGhostText() {
        // Username Placeholder
        jTextField1.setForeground(Color.GRAY);
        jTextField1.setText(USER_PLACEHOLDER);
        jTextField1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (jTextField1.getText().equals(USER_PLACEHOLDER)) {
                    jTextField1.setText("");
                    jTextField1.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (jTextField1.getText().isEmpty()) {
                    jTextField1.setForeground(Color.GRAY);
                    jTextField1.setText(USER_PLACEHOLDER);
                }
            }
        });

        // Password Placeholder
        jPasswordField1.setForeground(Color.GRAY);
        jPasswordField1.setEchoChar((char) 0); // Show text
        jPasswordField1.setText(PASS_PLACEHOLDER);
        jPasswordField1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                String pwd = new String(jPasswordField1.getPassword());
                if (pwd.equals(PASS_PLACEHOLDER)) {
                    jPasswordField1.setText("");
                    jPasswordField1.setForeground(Color.BLACK);
                    // Unicode escape avoids source-encoding issues.
                    jPasswordField1.setEchoChar('\u2022');
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (new String(jPasswordField1.getPassword()).isEmpty()) {
                    jPasswordField1.setForeground(Color.GRAY);
                    jPasswordField1.setEchoChar((char) 0); // Show text
                    jPasswordField1.setText(PASS_PLACEHOLDER);
                }
            }
        });
    }
    // --- UI FEATURE: NUMBER FILTER ---

    // --- UI FEATURE: NUMBER FILTER ---
    private void setupNumberOnlyFilter() {
        ((javax.swing.text.AbstractDocument) jTextField1.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws javax.swing.text.BadLocationException {
                // Allow numeric Employee ID input and placeholder writes.
                if (string.matches("[0-9]+") || USER_PLACEHOLDER.equals(string)) {
                    super.insertString(fb, offset, string, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws javax.swing.text.BadLocationException {
                // Allow numeric Employee ID input and placeholder writes.
                if (text.matches("[0-9]*") || USER_PLACEHOLDER.equals(text)) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(400, 600));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/motorph/ui/resources/images/Logo2.png"))); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel1.setMaximumSize(new java.awt.Dimension(100, 350));
        jLabel1.setMinimumSize(new java.awt.Dimension(100, 350));
        jLabel1.setOpaque(true);
        jLabel1.setPreferredSize(new java.awt.Dimension(100, 350));
        java.net.URL url = getClass().getResource(
            "/com/motorph/ui/resources/images/Logo2.png"
        );
        if (url != null) {
            javax.swing.ImageIcon icon = new javax.swing.ImageIcon(url);
            java.awt.Image img = icon.getImage();

            int w = jLabel1.getWidth();
            int h = jLabel1.getHeight();

            if (w > 0 && h > 0) {
                java.awt.Image scaled = img.getScaledInstance(
                    w, h, java.awt.Image.SCALE_SMOOTH
                );
                jLabel1.setIcon(new javax.swing.ImageIcon(scaled));
            }
        }
        getContentPane().add(jLabel1, java.awt.BorderLayout.PAGE_START);

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/motorph/ui/resources/images/Username.png"))); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jLabel2.setMaximumSize(new java.awt.Dimension(30, 30));
        jLabel2.setMinimumSize(new java.awt.Dimension(30, 30));
        jLabel2.setPreferredSize(new java.awt.Dimension(30, 30));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 7, 3, 7);
        jPanel1.add(jLabel2, gridBagConstraints);

        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("EMPLOYEE ID");
        jTextField1.setToolTipText("");
        jTextField1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jTextField1.setMargin(new java.awt.Insets(3, 7, 3, 7));
        jTextField1.setMaximumSize(new java.awt.Dimension(75, 25));
        jTextField1.setMinimumSize(new java.awt.Dimension(75, 25));
        jTextField1.setName(""); // NOI18N
        jTextField1.setPreferredSize(new java.awt.Dimension(75, 25));
        jTextField1.addActionListener(this::jTextField1ActionPerformed);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 7, 3, 7);
        jPanel1.add(jTextField1, gridBagConstraints);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/motorph/ui/resources/images/Password.png"))); // NOI18N
        jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel4.setMaximumSize(new java.awt.Dimension(30, 30));
        jLabel4.setMinimumSize(new java.awt.Dimension(30, 30));
        jLabel4.setPreferredSize(new java.awt.Dimension(30, 30));
        jLabel4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipady = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 7, 3, 7);
        jPanel1.add(jLabel4, gridBagConstraints);

        jPasswordField1.setColumns(20);
        jPasswordField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPasswordField1.setText("PASSWORD");
        jPasswordField1.setToolTipText("");
        jPasswordField1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPasswordField1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPasswordField1.setMargin(new java.awt.Insets(3, 7, 3, 7));
        jPasswordField1.setMaximumSize(new java.awt.Dimension(75, 25));
        jPasswordField1.setMinimumSize(new java.awt.Dimension(75, 25));
        jPasswordField1.setRequestFocusEnabled(true);
        jPasswordField1.addActionListener(this::jPasswordField1ActionPerformed);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 7, 3, 7);
        jPanel1.add(jPasswordField1, gridBagConstraints);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setText("Login");
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setMargin(new java.awt.Insets(5, 10, 5, 10));
        jButton1.setPreferredSize(new java.awt.Dimension(50, 25));
        jButton1.addActionListener(this::jButton1ActionPerformed);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(5, 10, 5, 10);
        jPanel1.add(jButton1, gridBagConstraints);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        performLogin();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
        performLogin();
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
        performLogin();
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

}
